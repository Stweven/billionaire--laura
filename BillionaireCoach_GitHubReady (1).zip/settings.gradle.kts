rootProject.name = "BillionaireCoach"
include(":app")
